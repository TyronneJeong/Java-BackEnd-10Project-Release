package com.fast.campus.simplesns.model;

public enum UserRole {
    USER,
    ADMIN
}
